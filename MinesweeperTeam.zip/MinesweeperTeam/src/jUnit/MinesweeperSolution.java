package jUnit;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MinesweeperSolution {

	public static void main(String[] args) throws IOException {
		File inputFile = new File(args[0]);
		Scanner kb = new Scanner(inputFile);
		FileWriter write = new FileWriter("output.txt");
		int row, col;
		int count = 1;
		
		do{
			String str = kb.nextLine();
			String[] strArrRowAndCol = str.split(" ");
			row = Integer.parseInt(String.valueOf(strArrRowAndCol[0]));
			col = Integer.parseInt(String.valueOf(strArrRowAndCol[1]));
			if(row != 0 && col != 0)	
				write.write("Field #" + count + ":\n");
			
			char[][] board = new char[row][col];
			
			for(int i = 0; i < row; i++) {	
				str = kb.nextLine();
				for(int j = 0; j < col; j++) {
					board[i][j] = str.charAt(j);
				}// end for loop j
			}//end for loop i
			
			solve(board);
			printBoard(write, board);
			System.out.println();
			count++;

		}while(row != 0 && col != 0);
		kb.close();
		write.close();
	}

	static void printBoard(FileWriter write, char[][] board) {

		for(int i = 0; i < board.length; i++) {	      
			for(int j = 0; j < board[i].length; j++) {
				try {
					write.write(board[i][j]);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}//end for loop j
			try {
				write.write("\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}//end for loop i

	}

	static void solve(char[][] board) {

		for(int i = 0; i < board.length; i++) {	      
			for(int j = 0; j < board[i].length; j++) {

				if(board[i][j] != '*') {
					int count = 0;
					boolean nw, n, ne, w, e, sw, s, se;
					nw = n = ne = w = e = sw = s = se = true;
					if(i == 0) ne = n = nw = false; 
					if(j == 0) nw = w = sw = false;
					if(i == board.length-1) sw = s = se = false;
					if(j == board[i].length - 1) ne = e = se = false;

					if(nw)
						if(board[i-1][j-1] == '*') count++;
					if(n)
						if(board[i-1][j]   == '*') count++;
					if(ne)
						if(board[i-1][j+1] == '*') count++;
					if(w)
						if(board[i]  [j-1] == '*') count++;
					if(e)
						if(board[i]  [j+1] == '*') count++;
					if(sw)
						if(board[i+1][j-1] == '*') count++;
					if(s)	
						if(board[i+1][j]   == '*') count++;
					if(se)	
						if(board[i+1][j+1] == '*') count++;

					board[i][j] = Character.forDigit(count,10);
				}//end if
			}//end for loop j
		}//end for loop i
	}

}