package jUnit;

import static org.junit.jupiter.api.Assertions.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.junit.jupiter.api.Test;

class JUnitTest {

	@Test
	void testMain1x1Mine() {
		String[] args = new String[1];
		args[0] = "tests/minetest1x1Mine.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected1x1Mine.txt"));
	}
	
	@Test
	void testMain1x1NoMine() {
		String[] args = new String[1];
		args[0] = "tests/minetest1x1NoMine.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected1x1NoMine.txt"));
	}
	
	@Test
	void testMain1x100AllMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest1x100AllMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected1x100AllMines.txt"));
	}
	
	@Test
	void testMain1x100NoMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest1x100NoMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected1x100NoMines.txt"));
	}
	
	@Test
	void testMain1x100HalfMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest1x100HalfMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected1x100HalfMines.txt"));
	}
	
	@Test
	void testMain100x1AllMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest100x1AllMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected100x1AllMines.txt"));
	}
	
	@Test
	void testMain100x1NoMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest100x1NoMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected100x1NoMines.txt"));
	}
	
	@Test
	void testMain100x1HalfMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest100x1HalfMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected100x1HalfMines.txt"));
	}
	
	@Test
	void testMain100x100AllMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest100x100AllMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected100x100AllMines.txt"));
	}
	
	@Test
	void testMain100x100NoMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest100x100NoMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected100x100NoMines.txt"));
	}
	@Test
	void testMain100x100HalfMines() {
		String[] args = new String[1];
		args[0] = "tests/minetest100x100HalfMines.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected100x100HalfMines.txt"));
	}
	
	@Test
	void testMain4x3() {
		String[] args = new String[1];
		args[0] = "tests/minetest4x3.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected4x3.txt"));
	}
	
	@Test
	void testMain7x7() {
		String[] args = new String[1];
		args[0] = "tests/minetest7x7.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected7x7.txt"));
	}
	
	@Test
	void testMain25x25() {
		String[] args = new String[1];
		args[0] = "tests/minetest25x25.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected25x25.txt"));
	}
	
	@Test
	void testMain16x8() {
		String[] args = new String[1];
		args[0] = "tests/minetest16x8.txt";
		try {
			MinesweeperSolution.main(args);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(CompareOutputVsExpected("output.txt", "expected/mineexpected16x8.txt"));
	}
	
	private static boolean CompareOutputVsExpected(String outputfile, String expectedfile) {
		try 
		{
			BufferedReader output = new BufferedReader(new FileReader(outputfile));
	        BufferedReader expected = new BufferedReader(new FileReader(expectedfile));
	        String outputline = output.readLine();
	        String expectedline = expected.readLine();
	        boolean equal = true;
	        int line = 1;
	         
	        while (outputline != null || expectedline != null)
	        {
	            if(outputline == null || expectedline == null)
	            {
	                equal = false;
	                break;
	            }
	            else if(! outputline.equalsIgnoreCase(expectedline))
	            {
	                equal = false;
	                break;
	            }
	            outputline = output.readLine();
	            expectedline = expected.readLine();
	            line++;
	        }
	        output.close();
	        expected.close();
	        return equal;
		}catch(Exception e) {
			
		}
		return false;
	}
}
